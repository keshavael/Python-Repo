#!/usr/bin/env python

x_dot=0
m=1
c=1
k=1
x=1
t=0.01
#Simulation spring mass champer for time step 0.01
for i in xrange(1001):
    acc=((-k*x-c*x_dot)/m)*t
    x_dot=acc+x_dot
    print i, x
    x= x+x_dot
