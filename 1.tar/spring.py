#!/usr/bin/env python


def spring_mass(m,c,k,x,x_dot,t):
    acc=((-k*x-c*x_dot)/m)*t
    return acc
