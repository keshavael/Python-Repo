#!/usr/bin/env python

#Calculate area of circle for radius from 0 to 10 with step size 0.5

from circle import *
for  i in xrange(21):
    n= i*0.5
    f= circle_area(n)
    print str(n)+" -> "+str(f)
