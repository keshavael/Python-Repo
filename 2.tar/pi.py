#!/usr/bin/env python
import math
def estimate_pi():
    k=0
    sum = 0
    while k>=0:
        x= ((2*math.sqrt(2))/9801)*(1103+26390*k)*(math.factorial(4*k))/((396**(4*k))*math.factorial(k))
        if x>= 1e-15:
            sum = x+sum
            k=k+1
        else:
            break
    print (1/sum)
           
    
    
