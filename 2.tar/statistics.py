#!/usr/bin/env python

from sensor import *
def statistics_filter(data):
    i=0
    n= len(data)
    print "Number of data -> ", n
    maxiumum= max(data)
    print "Max -> ", maxiumum
    minimum=min(data)
    print "Min -> ", minimum
    mean= sum(data)/n
    print "Mean -> " , mean
    nom= [(x-mean)**2 for x in data]
    power = [x**2 for x in nom]
    p= sum(power)
    var = p/(n-1)
    standard_dev = var**0.5
    print "Standard deviation -> ", standard_dev
    sort_list=sorted(data)
    if n%2==0:
        t=int(n/2)
        median = (sort_list[t-1]+ sort_list[t])/2.0
        print "Median -> ", median
    else:
        print "Median -> ", sort_list[t]
    
    ul=mean+standard_dev
    ll= mean-standard_dev
    for x in data :
        if x<ll or x>ul:
            i=i+1
    per= i*100.0/n
    print "Percentage of data farther than 1 sigma from mean -> ",  "%",per
if __name__ == '__main__':
    data = generate_sensor_data()
