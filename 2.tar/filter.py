#!/usr/bin/env python
from sensor import *

def apply_null_filter(data):
    n=len(data)
    meandata=[data[0]]
    for i in range(int(1),int(n-1)):
        meandata=meandata+[data[i-1]+data[i]+data[i+1]]
        i=i+1

    filtered =[x/3 for x in meandata]

    #for datum in data:
    #filtered.append(datum)
    ff= len(filtered)
    print ff
    return filtered
    


if __name__ == '__main__':
    data = generate_sensor_data()

    filtered_data = apply_null_filter(data)
    
    print_sensor_data(data, 'raw')
    print_sensor_data(filtered_data, 'filtered')


