#!/usr/bin/env python


from sensor import *

def median_filter(data, width=7):

    median=[]
    l=int(width/2)
    if width %2 ==0:
        print "Width should be odd number, try again"
        quit()
    else:
        start= int(width/2)
        end = len(data)-start
        for i in range(start,end):
            new=[]
            for j in range(int(i-l),int(i+l)):
                new=new+[data[j]]
                j=j+1
                sor=sorted(new)
            median=median+[sor[l]]
            i=i+1
        
        print median
            

    #for datum in data:
        #filtered.append(datum)

    
if __name__ == '__main__':
    data = generate_sensor_data()

    #filtered_data = apply_null_filter(data)
    
    #print_sensor_data(data, 'raw')
    #print_sensor_data(filtered_data, 'filtered')



