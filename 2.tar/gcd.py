#!/usr/bin/env python

def gcd_finder(a,b):
    ans =0
    if a!=int(a) or b!=int(b): 
        print("Sorry, inputs must be integers, try again")
        quit() 
    if a<=0 or b<=0:
        print("Sorry, input must be positive, try again")
        quit()
    
    x=max(a,b)
    #print x
    y=a*b
    #print y
    for i in range(y,x-1,-1):
        #print i
        if i%a==0 and i%b==0:
            ans= i
        continue
        break
    print ans        
    