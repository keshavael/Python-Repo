#!/usr/bin/env python


from sensor import *

def mean_filter(data, width=5):
    s=[]
    mean=[]
    l=int(width/2)
    if width %2 ==0:
        print "Width should be odd number, try again"
        quit()
    else:
        start= int(width/2)
        end = len(data)-start
        for i in range(start,end):
            new=[0]
            for j in range(int(i-l),int(i+l)):
                new=new+[data[int(j)]]
                j=j+1
                
            seg= sum(new)
            mean=mean+[seg]
            i=i+1
        
        filtered =[x/width for x in mean]
        print filtered
        print len(filtered)

    
if __name__ == '__main__':
    data = generate_sensor_data()

    #filtered_data = apply_null_filter(data)
    
    #print_sensor_data(data, 'raw')
    #print_sensor_data(filtered_data, 'filtered')



