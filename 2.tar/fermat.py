#!/usr/bin/env python

# Fermet last theorem for positive integer a b c
# n should be greater than 2
# We want to check if there is a^n+b^n=c^n


def fermat_last(a,b,c,n):
        if a!=int(a) or b!=int(b) or c!=int(c) or n!=int(n): 
                print("Sorry, inputs must be integers, try again")
                quit() 
        if a<=0 or b<=0 or c<=0 or n<=0:
                print("Sorry, inputs must be positive, try again")
                quit() 
        if n<3:
                print("Sorry, n must be greater than 2")
                quit()
        for i in range(3,n):
                        #x=a**i+b**i
                        #y=c**i
                        #print "x", x
                        #print "y", y
                        if a**n+b**n ==c**n:
                                print "a,b,c,n",a,b,c,n
                                print "Holy smokes,Fermat was wrong!"
                                continue
                                break              
        print("No, that does not work.")
        
                  
