#!/usr/bin/env python


import cmath
from math import sqrt

class Complex:
 
    def __init__(self,re = 0.0,im = 0.0):
        self.re = re
        self.im = im
        

    def __str__(self):
        #Returns complex number as a string
        return '({0} + {1}i)'.format(self.re, self.im)


    def __add__(self, second):
        #REturn summation    
        if isinstance(second, (float,int))==True:
            second = Complex(second)
        new_real_part = self.re + second.re
        new_imag_part = self.im + second.im
        return Complex(new_real_part, new_imag_part)

    def __radd__(self, second):
        if isinstance(second, (float,int))==True:
            second = Complex(second)
        new_real_part = self.re + second.re
        new_imag_part = self.im + second.im
 
        return Complex(new_real_part, new_imag_part)


    def __sub__(self, second):
        #Return subtraction
        if isinstance(second, (float,int)):
            second = Complex(second)
        new_real_part = self.re - second.re
        new_imag_part = self.im - second.im
        return Complex(new_real_part, new_imag_part)

    def __rsub__(self, second):
        #Return subtraction
        if isinstance(second, (float,int))==True:
            second = Complex(second)          
       
        new_real_part = self.re +(-1* second.re)
        new_imag_part = self.im +(-1* second.im)
        return Complex(new_real_part, new_imag_part)

    def __mul__(self, second):         
        #Return the product
        if isinstance(second, (float,int))==True:
            second = Complex(second)
        new_real_part = self.re * second.re - self.im * second.im 
        new_imag_part = self.im * second.re + self.re * second.im
        return Complex(new_real_part, new_imag_part)

    def __rmul__(self, second):
        #Return mulipication
        if isinstance(second, (float,int))==True:
            second = Complex(second)
        new_real_part = self.re * second.re - self.im * second.im 
        new_imag_part = self.im * second.re + self.re * second.im
        return Complex(new_real_part, new_imag_part)

        
    def __div__(self, second):
        #Return diviation
        if isinstance(second, (float,int))==True:
            second = Complex(second)
        if (second.re*second.re+ second.im*second.im)==0:
            return 'denominator can not be zero, Please Try again'
            quit() 
        new_real_part = (self.re * second.re + self.im * second.im)/(second.re*second.re+ second.im*second.im)
        new_imag_part = (self.im * second.re - self.re * second.im)/(second.re*second.re+ second.im*second.im)
        return Complex(new_real_part, new_imag_part)

    def __rdiv__(self, second):
        if isinstance(second, (float,int))==True:
            second = Complex(second)
        if (second.re*second.re+ second.im*second.im)==0:
            return 'denominator can not be zero, Please Try again'
            quit()  
        new_real_part = (self.re * second.re + self.im * second.im)/(second.re*second.re+ second.im*second.im)
        new_imag_part = (self.im * second.re - self.re * second.im)/(second.re*second.re+ second.im*second.im)
        return Complex(new_real_part, new_imag_part)

    def con(self):
        #Return conjugate
        new_real_part = self.re
        new_imag_part = -1* self.im
        return Complex(new_real_part, new_imag_part)

def com_test(a,b,c,d):
    z1=complex(a,b)
    z2=complex(c,d)
    sumAns= z1+z2
    subAns = z1-z2
    mulAns=z1*z2
    divAns=z1/z2
    print 'Sum Test:', sumAns
    print 'Subtract Test:', subAns
    print 'multiply Test:', mulAns
    print 'Division Test:', divAns


    

def roots(a=0.0,b=0.0,c=0.0):
    if a==0 and b==0:
        return 'There is', 'No roots'
    elif a==0:
        oneroot = -c/b
        print 'THere is just one root'
        return oneroot, 'None'
        
    d = (b**2)-(4*a*c)
    if d>=0:
        x=d**0.5
        root1 = (-b-x)/(2*a)
        root2 = (-b+x)/(2*a)

    if d<0:
        d2=-1.0*d
        d3=sqrt(d2)
        p = d3/(2*a)
        t= -b/(2*a)
        root1 = Complex(t,p)
        root2 = Complex(t,-p)
    print "Test if the root1 meet the condition ax^2+bx+c=0"
    print a*(root1*root1) +b*root1 +c
    print "Test if the root2 meet the condition ax^2+bx+c=0"
    print a*(root2*root2) +b*root2 +c
       
    return root1, root2
    



    
    
        

# I got help from our TA Carrie
# I got help from our TA Corry 
# I got help from my friend Nathan
#I got help from https://en.wikipedia.org/wiki/Complex_number#Multiplication_and_division
# I got help from http://stackoverflow.com/questions/12486828/python-making-a-class-to-use-complex-numbers
    
#print Complex()
#print Complex(1.2)
#print Complex(-3.2,0.1)
b=Complex(4,-3.6)
#b=8.5
a=Complex(-2.1,3.4)
#a=-8

#print b
#print a-b
#print a*b
#print a/b

#com_test(-2.1,3.4,4,-3.6)
#conj=Complex.con(a)
#print 'con', conj

a1, b1 = roots(-8,20,9)
print 'Roots are', a1,b1

