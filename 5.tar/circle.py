#!/usr/bin/env python


import math
from math import pi

class circle:

    def __init__(circle , radius):
        circle.raduis = radius

    def area(circle):
        #Returns area of the circle
        a = pi*(circle.raduis**2)
        return a


    def diameter(circle):
        #Returns diameter
        d = 2*circle.raduis
        return  d 

    def circumference(circle):
        #Returns the circumference of the circle
        c= 2*pi*circle.raduis
        return c


def test_circle(r):
    #Test area 
    a = (r**2)*pi
    b= r*2
    c= b*pi
    print 'Test Area:', a
    print 'Test Diameter:' , b
    print 'Test Circumestance:' , c
    



p=circle(1)
print p.area()
print p.diameter()
print p.circumference()

test_circle(1)



