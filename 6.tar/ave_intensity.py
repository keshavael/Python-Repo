#!/usr/bin/env python

from pic import*
import numpy as np

from pic import Webcam 


w=Webcam()
d=w.grab_image_data()
r=0
g=0
b=0
l=len(d)
for i in d:
	r+=i[0]
	g+=i[1]
	b+=i[2]
inten=(r+g+b)/(3*l)
print 'intensity is:', inten




