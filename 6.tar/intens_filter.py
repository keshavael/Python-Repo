#!/usr/bin/env python

from pic import*
import numpy as np

from pic import Webcam 
import matplotlib.pyplot as plt
def intens_filter():	
	intensity=[]
	filtered =[]
	for k in xrange(0,1000,1):	
		w=Webcam()
		# d is the data for image 
		#lenght of d is 786432
		d=w.grab_image_data()
		#r g and b are red green and blue color of a photo 
		r=0
		g=0
		b=0
		for x in d:
			r+=x[0]
			g+=x[1]
			b+=x[2]	
		intens=(r+g+b)/(3*len(d))
		intensity.append(intens)	
	
	print 'intensity is:', intensity
	l=len(intensity)
	a=intensity[0]
	b=intensity[l-1]
	start= int(3/2)
	s= int(3/2)
	end = l-start
	for i in range(start,end):
		new=[]
		for j in range(int(i-1),int(i+1)):
			new=new+[intensity[j]]
			sor=sorted(new)
		filtered=filtered+[sor[1]]
		i=i+1     
	finalfiltered=[a]+filtered+[b]
	print 'filtered data is :',finalfiltered	            	 	
	h= range(0,1000,1)
	plt.plot(h,intensity,'r', label='Original Intensity')
	plt.plot(h,finalfiltered,'g', label='Filtered Intensity')
	plt.xlabel('Seconds')
	plt.ylabel('Average of Intensity')
	plt.ylim([0,120])
	plt.title('Intensity over the Time')
	plt.legend()
	plt.show()
intens_filter()	
