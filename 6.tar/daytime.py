#!/usr/bin/env python

from pic import*
import numpy as np

from pic import Webcam 
import matplotlib.pyplot as plt
def daytime():	
	w=Webcam()
	# d is the data for image 
	#lenght of d is 786432
	d=w.grab_image_data()
	#r g and b are red green and blue color of a photo 
	r=0
	g=0
	b=0
	for x in d:
		r+=x[0]
		g+=x[1]
		b+=x[2]	
	intensity = (r+g+b)/(3*len(d))
	print intensity	
	if intensity >= 85:
		print 'True.', 'It is day time' 
	else:
		print 'False.', 'It is night time'
		 			
daytime()