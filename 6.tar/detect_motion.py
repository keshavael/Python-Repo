#!/usr/bin/env python

from pic import*
import numpy as np
import time
from pic import Webcam 
import matplotlib.pyplot as plt
from scipy.spatial import distance

def detect_motion():	
	w=Webcam()
	d=w.grab_image_data()
	total=[0]
	time.sleep(5)
	wd=Webcam()
	t=wd.grab_image_data()
	l=len(t)
	for i in xrange(262144,l,1):
		# Reference: I learnd distance.euclidean from:
		# http://stackoverflow.com/questions/1401712/how-can-the-euclidean-distance-be-calculated-with-numpy
		dst = distance.euclidean(d[i],t[i])
		total.append(dst)
	ave_dis= np.mean(total)
	print 'Average pixel difference is: ', ave_dis
	if ave_dis > 5.4:
		print 'True.','There is movement on the quad'
	else:
		print 'False.', 'There is NO movement on the quad'
detect_motion()
# Make it robust by several times measurements 
# and figure it out that if there is no movement distance can be vary till 5.5
# because of rain, reflection of the lights, wind 
# also by limiting the pixel to the quad
#if there is real movement distance is higher than 5.5
# hight movement 7.11, 7.96, 7.9, 
# low movements 6.33,6.31, 6.13, 5.94, 5,65, 5.6, 
#no movements 4.94, 5.23, 5.34, 4.88, 4.86
#high movement no event 9.49, 10.64, 8.44, 8.34
