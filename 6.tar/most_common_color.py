#!/usr/bin/env python

from pic import*
import numpy as np

from pic import Webcam 
import matplotlib.pyplot as plt
def most_common_color():	
	w=Webcam()
	# d is the data for image 
	#lenght of d is 786432
	d=w.grab_image_data()
	#r g and b are red green and blue color of a photo 
	r=0
	g=0
	b=0
	for x in d:
		r+=x[0]
		g+=x[1]
		b+=x[2]
	redpro=100*r/(r+g+b)
	greenpro=100*g/(r+g+b)
	bluepro=100*b/(r+g+b)
	print 'Red proportion is: %', redpro
	print 'Green proportion is: %', greenpro
	print 'Blue proportion is: %', bluepro	
	if g>0 and r>0 and b>0 and g==r==b:
		print 'White is the most common color'
	if g==r==b==0:
		print 'Black is the most common color'			
	if r>g and r>b:
		print 'Red is the most common color with %',redpro
	if g>r and g>b:
		print 'Green is the most common color with %',greenpro
	else:
		print 'Blue is the most common color with %',bluepro
		
		
most_common_color()


# colors definition
#http://www.discoveryplayground.com/computer-programming-for-kids/rgb-colors/