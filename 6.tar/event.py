#!/usr/bin/env python

from pic import*
import numpy as np
import time
from pic import Webcam 
import matplotlib.pyplot as plt
from scipy.spatial import distance

def mu_event():	
	w=Webcam()
	d=w.grab_image_data()
	r=0
	g=0
	b=0
	main_red_pro= 33
	main_green_pro=38
	main_blue_pro =29
	for x in d[262144:524288]: 
		r+=x[0]
		g+=x[1]
		b+=x[2]	
	#k=0	
	#for x in d[262144:524288]: 		
		#if x[0]==100 and x[1]==100 and x[2]==100:
			#k=k+1
	#print 'gray pixel', k
	redpro=100*r/(r+g+b)
	greenpro=100*g/(r+g+b)
	bluepro=100*b/(r+g+b)
	print 'Red proportion is: %', redpro
	print 'Green proportion is: %', greenpro
	print 'Blue proportion is: %', bluepro	
	print 'Average pixel difference is: ', 
	if bluepro-main_blue_pro>2: #or bluepro-main_blue_pro<-2
		print 'True.','There is an event on the quad'
	else:
		print 'False.', 'There is NO event on the quad'
mu_event()

# I got the average from getting the proporstion several time 