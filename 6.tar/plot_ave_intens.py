#!/usr/bin/env python

from pic import*
import numpy as np

from pic import Webcam 
import matplotlib.pyplot as plt
intensity=[]
for j in xrange(0,100,1):	
	w=Webcam()
	# d is the data for image 
	#lenght of d is 786432
	d=w.grab_image_data()
	#r g and b are red green and blue color of a photo 
	r=0
	g=0
	b=0
	for i in d:
		r+=i[0]
		g+=i[1]
		b+=i[2]	
	intens=(r+g+b)/(3*len(d))
	intensity.append(intens)

print 'intensity is:', intensity 	
h= range(0,100,1)
plt.plot(h,intensity,'r')
plt.xlabel('Seconds')
plt.ylabel('Average of Intensity')
plt.ylim([0,120])
plt.title('Intensity over the Time')
plt.show()