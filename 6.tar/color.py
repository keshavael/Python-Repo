#!/usr/bin/env python


import numpy as np
from pic import *
from scipy import stats
from colorname import *

def most_common_color():
	w=Webcam()
	d=w.grab_image_data()
	part = d[100000::2500]
	reconst = ["%s,%s,%s" %x for x in part]
	mode,num = stats.mode(reconst)
	print num
	clean = mode[0].split(',')
	red = int(clean[0])
	green = int(clean[1])
	blue = int(clean[2])
	print mode
	color = ColorNames()
	print color.findNearestWebColorName((red,green,blue))
 

    
most_common_color()
#(100,107,47)
#(83,113,5)
# usually it gives me different green during the day and red at night
#dark olive green 
#references
#    I got help from Jalen for this 
