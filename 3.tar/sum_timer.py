#!/usr/bin/env python

import time 
import numpy as np
import matplotlib.pyplot as plt 
mytimelist=[]
g=[10**(x) for x in range(7)]
for x in g:
	s=[np.random.rand(x)]
	start =time.time()
	total= np.sum(s)
	end= time.time()
	l=end-start
	mytimelist.append(l)
k=plt.plot(g, mytimelist)
plt.title('Run time to Sum for different Sample Size')
plt.xlabel('Sample Size')
plt.ylabel('Time to Sum')
plt.show()