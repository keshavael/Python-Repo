#!/usr/bin/env python
#import numpy
import numpy as np
import matplotlib.pyplot as plt
t=np.arange(0.0, 4.0*np.pi, 0.01)
s=np.sin(t)
k=plt.plot(t,s,'b')
plt.axis([0, 4.0*np.pi,-1,1])
plt.xlabel('x')
plt.ylabel('sinx')
plt.title('A sin curve')
plt.show()
