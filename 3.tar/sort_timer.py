#!/usr/bin/env python
#import numpy
import time 
import numpy as np
import matplotlib.pyplot as plt 
mytimelist=[]
g=[10**(x) for x in range(7)]
for x in g:
	s=[np.random.rand(x)]
	start =time.time()
	sor = sorted(s)
	end= time.time()
	l=end-start
	mytimelist.append(l)
k=plt.plot(g, mytimelist)
plt.title('Run time to Sort for different Sample Size')
plt.xlabel('Sample Size')
plt.ylabel('Time to Sort')
plt.show()