#!/usr/bin/env python
import numpy as np
import matplotlib.pyplot as plt
def clt_check(n=10000):
    mylist= []
    for i in range(int(n)):
        s=np.sum(np.random.uniform(0,1,10))
        mylist.append(s)
    n, bins, patches = plt.hist(mylist, 50, normed=1, facecolor='g', alpha=0.75)
    plt.xlabel('Sum of sample')
    plt.ylabel('number of sample')
    plt.title('Histogram of Sample Sum')
    
if __name__ == '__main__':
    clt_check()
    plt.show()
