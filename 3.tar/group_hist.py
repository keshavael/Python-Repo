#!/usr/bin/env python
from clt_check import *
import numpy as np
import matplotlib.pyplot as plt

g=[10**(x+1) for x in range(6)]
c= len(g)
for x in range(c):
	plt.subplot(3,2,x+1)
	clt_check(g[x])
	plt.title('Sample size Histogram for different Sample Size')
plt.show()
	


