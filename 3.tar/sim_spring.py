#!/usr/bin/env python

from spring import *
import matplotlib.pyplot as plt 
import numpy as np

spr = SpringMassDamper(10.0 , 10.0 , 1.0)
st,t = spr.simulate(0.0 , 1.0)
plt.plot(t,st[:,0])
plt.xlabel('time')
plt.ylabel('State')
plt.title('Spring Simulation')
plt.show()
