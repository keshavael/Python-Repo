#!/usr/bin/env python

import numpy as np
import matplotlib.pyplot as plt 
import time
from bubble_sort import *
from myquick_sort import *
from insert_sort import *


avequick =[]
quicktime= []    
avebuild = []
buildtime = []
bubbletime=[]
avebubble =[]
mytimelist = []
inserttime =[]
avesort = []
for u in xrange(100,2100,100):
    mainlist = np.random.uniform(-100.0,100.0,u)
    #print 'Main Unsorted List', mainlist

    k=10

    print 'Sorted'	
    for j in range(int(k)):
        started1 =time.time()
        build=sorted(mainlist)
        #print 'Sorted List by build-in Method', build
        end1= time.time()
        l1=end1-started1
        buildtime.append(l1)
    ave1=np.average(buildtime)
    avebuild.append(ave1)
        
    print 'bubble'        
    for j in range(int(k)):
        started2 =time.time()
        x=bubble_sort(mainlist)
        #a= bubble_sort(mainlist)
        #print 'bubble', a
        end2= time.time()
        l2=end2-started2
        bubbletime.append(l2)
    ave2=np.average(bubbletime)
    avebubble.append(ave2)

    for j in range(int(k)):
        started3 =time.time()
        #print ' inner Q {0}'.format(is_sorted(mainlist))        
        x = myquick_sort(mainlist)
        #print ' inner Q {0}'.format(is_sorted(x))

        #g=myquick_sort(mainlist)
        #print 'Sorted List by Quick', g

        end3= time.time()
        l3=end3-started3
        quicktime.append(l3)
    ave3=np.average(quicktime)
    avequick.append(ave3)
        

    for j in range(int(k)):
        started4 =time.time()
        insert_sort(mainlist)
        #c= insert_sort(mainlist)
        #print 'Sorted List by Insert', c
        end4= time.time()
        l4=end4-started4
        inserttime.append(l4)
    ave4=np.average(inserttime)
    avesort.append(ave4)
      
h= range(100,2100,100)
plt.semilogy(h, avebuild,'b--', label='Build in Sort Time')
plt.semilogy(h, avebubble,'r--', label='Bubble Sort Time')
plt.semilogy(h, avequick,'g--', label='Quick in Sort Time')
plt.semilogy(h, avesort,'k--', label='Insert Sort Time')
plt.title('Run Time comparison for Different Sort Methods')
plt.xlabel('List Lenght')
plt.ylabel('Time to Sort')
plt.legend()
plt.show()



