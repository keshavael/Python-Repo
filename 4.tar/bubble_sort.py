#!/usr/bin/env python

import numpy as np
from copy import copy

def bubble_sort(mainlist):
	#print 'inner {0}'.format(is_sorted(mainlist))
	templist = copy(mainlist)
	for k in range(len(templist)-1, 0,-1):
		for i in range(k):
			if templist[i]>templist[i+1]:
				s = templist[i]
				templist[i] = templist[i+1]
				templist[i+1] = s
	return templist
	 
	 
def is_sorted(data):
	for n in xrange(len(data)-1):
		if data[n] > data[n+1]: return False
	
	return True	
	

#mainlist = np.random.uniform(-1.0,1.0,100)
#print 'Main Unsorted List', mainlist
#bubble_sort(mainlist)
#print mainlist

# Reference: I learned this line from Dr.smart code when his collegue was showing different sort methods in the class
# Also I used this website:
# http://interactivepython.org/runestone/static/pythonds/SortSearch/TheBubbleSort.html
    
    
