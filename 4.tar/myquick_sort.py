#!/usr/bin/env python

import numpy as np
from copy import copy
from random import randint  


def myquick_sort(templist):
    if len(templist) <= 1: return templist
    #templist = copy(mainlist)
    v = randint(0, len(templist)-1)  
    #int(len(templist))/2
    pivot = templist[v]
    return (myquick_sort([x for x in templist if x<pivot ]) +
    				[x for x in templist if x==pivot] +
    	        myquick_sort([x for x in templist if x>pivot])
    	        )
        
#mainlist = np.random.uniform(-1.0,1.0,100)
#print 'Main Unsorted List', mainlist
#g=myquick_sort(mainlist)


#Reference : I got help fromhttp://stackoverflow.com/questions/18262306/quick-sort-with-python
# I also got help from Alberto 
