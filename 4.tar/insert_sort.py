#!/usr/bin/env python

import numpy as np
from copy import copy

def insert_sort(mainlist):
	templist = copy(mainlist)
	for i in range(1, len(templist)):
		j = i
		while j > 0 and templist[j] < templist[j-1]:
			templist[j], templist[j-1] = templist[j-1], templist[j]
			j -= 1
	return templist
                 
#mainlist = np.random.uniform(-1.0,1.0,100)
#print 'Main Unsorted List', mainlist
#insert_sort(mainlist)
#print mainlist

# Reference: I learned this from this website 
# http://interactivepython.org/runestone/static/pythonds/SortSearch/TheInsertionSort.html
    
    
